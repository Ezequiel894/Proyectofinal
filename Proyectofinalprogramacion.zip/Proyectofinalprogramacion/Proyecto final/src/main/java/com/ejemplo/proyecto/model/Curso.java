package com.ejemplo.proyecto.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Column;

@Entity
public class Curso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long codigoCurso; // ID único para el curso

    @Column(name = "nombre_curso")
    private String nombreCurso;

    @Column(name = "descripcion_curso")
    private String descripcionCurso;

    @Column(name = "duracion_curso")
    private int duracionCurso; // Duración en horas o días (dependiendo de cómo lo definas)

    // Constructor vacío (requerido por JPA)
    public Curso() {}

    // Constructor con parámetros para facilitar la creación
    public Curso(String nombreCurso, String descripcionCurso, int duracionCurso) {
        this.nombreCurso = nombreCurso;
        this.descripcionCurso = descripcionCurso;
        this.duracionCurso = duracionCurso;
    }

    // Getters y Setters
    public long getCodigoCurso() {
        return codigoCurso;
    }

    public void setCodigoCurso(long codigoCurso) {
        this.codigoCurso = codigoCurso;
    }

    public String getNombreCurso() {
        return nombreCurso;
    }

    public void setNombreCurso(String nombreCurso) {
        this.nombreCurso = nombreCurso;
    }

    public String getDescripcionCurso() {
        return descripcionCurso;
    }

    public void setDescripcionCurso(String descripcionCurso) {
        this.descripcionCurso = descripcionCurso;
    }

    public int getDuracionCurso() {
        return duracionCurso;
    }

    public void setDuracionCurso(int duracionCurso) {
        this.duracionCurso = duracionCurso;
    }

    @Override
    public String toString() {
        return "Curso{" +
                "codigoCurso=" + codigoCurso +
                ", nombreCurso='" + nombreCurso + '\'' +
                ", descripcionCurso='" + descripcionCurso + '\'' +
                ", duracionCurso=" + duracionCurso +
                '}';
    }
}
