package com.ejemplo.proyecto.repository;

import com.ejemplo.proyecto.model.estudiante;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface repositorioestudiante extends JpaRepository<estudiante, Long> {
    // Aquí puedes agregar métodos de consulta personalizados si lo necesitas
}
