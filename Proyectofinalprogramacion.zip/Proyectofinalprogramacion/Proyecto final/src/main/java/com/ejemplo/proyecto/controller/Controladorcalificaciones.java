package com.ejemplo.proyecto.controller;

import com.ejemplo.proyecto.model.Calificaciones;
import com.ejemplo.proyecto.repository.repositoriocalificaciones;
import com.ejemplo.proyecto.repository.repositorioestudiante;
import com.ejemplo.proyecto.repository.Repositoriocurso;
import com.ejemplo.proyecto.model.estudiante;
import com.ejemplo.proyecto.model.Curso;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;










@RestController
@RequestMapping("/api/calificaciones")
public class Controladorcalificaciones {

    @Autowired
    private repositoriocalificaciones calificacionRepository;

    @Autowired
    private repositorioestudiante estudianteRepository;

    @Autowired
    private Repositoriocurso cursoRepository;

    // Obtener todas las calificaciones
    @GetMapping
    public ResponseEntity<Iterable<Calificaciones>> getAllCalificaciones() {
        Iterable<Calificaciones> calificaciones = calificacionRepository.findAll();
        return ResponseEntity.ok(calificaciones);
    }

    // Obtener una calificación por su ID
    @GetMapping("/{id}")
    public ResponseEntity<Calificaciones> getCalificacionById(@PathVariable Long id) {
        Optional<Calificaciones> calificacion = calificacionRepository.findById(id);
        return calificacion.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Crear una nueva calificación
    @PostMapping
    public ResponseEntity<Calificaciones> createCalificacion(@RequestBody Calificaciones calificacion) {
        // Verificar si el estudiante y el curso existen en la base de datos
        Optional<estudiante> estudiante = estudianteRepository.findById(calificacion.getEstudiante().getCodigoEstudiante());
        Optional<Curso> curso = cursoRepository.findById(calificacion.getCurso().getCodigoCurso());

        if (estudiante.isPresent() && curso.isPresent()) {
            Calificaciones savedCalificacion = calificacionRepository.save(calificacion);
            return ResponseEntity.status(201).body(savedCalificacion);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    // Actualizar una calificación existente
    @PutMapping("/{id}")
    public ResponseEntity<Calificaciones> updateCalificacion(@PathVariable Long id, @RequestBody Calificaciones calificacionDetails) {
        Optional<Calificaciones> calificacion = calificacionRepository.findById(id);
        if (calificacion.isPresent()) {
            Calificaciones existingCalificacion = calificacion.get();
            existingCalificacion.setCalificacion(calificacionDetails.getCalificacion());
            existingCalificacion.setEstudiante(calificacionDetails.getEstudiante());
            existingCalificacion.setCurso(calificacionDetails.getCurso());
            Calificaciones updatedCalificacion = calificacionRepository.save(existingCalificacion);
            return ResponseEntity.ok(updatedCalificacion);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Eliminar una calificación
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCalificacion(@PathVariable Long id) {
        Optional<Calificaciones> calificacion = calificacionRepository.findById(id);
        if (calificacion.isPresent()) {
            calificacionRepository.delete(calificacion.get());
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
