package com.ejemplo.proyecto.repository;

import com.ejemplo.proyecto.model.inscripciones;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface repositorioinscripciones extends JpaRepository<inscripciones, Long> {
    // Aquí puedes agregar métodos personalizados para consultas complejas si es necesario
}
