package com.ejemplo.proyecto.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class inscripciones {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long codigoInscripcion;  // ID único para la inscripción

    @ManyToOne
    private estudiante estudiante;  // El estudiante inscrito

    @ManyToOne
    private Curso curso;  // El curso en el que el estudiante se ha inscrito

    private String fechaInscripcion;  // Fecha en que se realizó la inscripción

    // Constructor vacío (requerido por JPA)
    public inscripciones() {}

    // Constructor con parámetros para facilitar la creación
    public inscripciones(estudiante estudiante, Curso curso, String fechaInscripcion) {
        this.estudiante = estudiante;
        this.curso = curso;
        this.fechaInscripcion = fechaInscripcion;
    }

    // Getters y Setters
    public long getCodigoInscripcion() {
        return codigoInscripcion;
    }

    public void setCodigoInscripcion(long codigoInscripcion) {
        this.codigoInscripcion = codigoInscripcion;
    }

    public estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(estudiante estudiante) {
        this.estudiante = estudiante;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public String getFechaInscripcion() {
        return fechaInscripcion;
    }

    public void setFechaInscripcion(String fechaInscripcion) {
        this.fechaInscripcion = fechaInscripcion;
    }

    @Override
    public String toString() {
        return "Inscripcion{" +
                "codigoInscripcion=" + codigoInscripcion +
                ", estudiante=" + estudiante.getNombreEstudiante() + " " + estudiante.getApellidoEstudiante() +
                ", curso=" + curso.getNombreCurso() +
                ", fechaInscripcion='" + fechaInscripcion + '\'' +
                '}';
    }
}
