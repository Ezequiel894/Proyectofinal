package com.ejemplo.proyecto.controller;

import com.ejemplo.proyecto.model.Profesor;
import com.ejemplo.proyecto.repository.repositorioprofresor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import java.util.Comparator;




@RestController
@RequestMapping("/api/profesores")
public class controladorprofesor {

    @Autowired
    private repositorioprofresor profesorRepository;

    // Obtener todos los profesores
    @GetMapping("/buscar")
    public ResponseEntity<Iterable<Profesor>> getProfesoresPorEspecializacion(@RequestParam String especializacion) {
        Iterable<Profesor> profesores = profesorRepository.findAll();

        // Filtramos los profesores por especialización y los recogemos en una lista
        List<Profesor> profesoresFiltrados = StreamSupport.stream(profesores.spliterator(), false)
                .filter(p -> p.getEspecializacion().toLowerCase().contains(especializacion.toLowerCase()))
                .collect(Collectors.toList());

        return ResponseEntity.ok(profesoresFiltrados);
    }


    // Obtener un profesor por su ID
    @GetMapping("/{id}")
    public ResponseEntity<Profesor> getProfesorById(@PathVariable Long id) {
        Optional<Profesor> profesor = profesorRepository.findById(id);
        return profesor.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Crear un nuevo profesor
    @PostMapping
    public ResponseEntity<Profesor> createProfesor(@RequestBody Profesor profesor) {
        Profesor savedProfesor = profesorRepository.save(profesor);
        return ResponseEntity.status(201).body(savedProfesor);
    }

    // Actualizar un profesor existente
    @PutMapping("/{id}")
    public ResponseEntity<Profesor> updateProfesor(@PathVariable Long id, @RequestBody Profesor profesorDetails) {
        Optional<Profesor> profesor = profesorRepository.findById(id);
        if (profesor.isPresent()) {
            Profesor existingProfesor = profesor.get();
            existingProfesor.setNombreProfesor(profesorDetails.getNombreProfesor());
            existingProfesor.setApellidoProfesor(profesorDetails.getApellidoProfesor());
            existingProfesor.setCorreoProfesor(profesorDetails.getCorreoProfesor());
            Profesor updatedProfesor = profesorRepository.save(existingProfesor);
            return ResponseEntity.ok(updatedProfesor);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Eliminar un profesor
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProfesor(@PathVariable Long id) {
        Optional<Profesor> profesor = profesorRepository.findById(id);
        if (profesor.isPresent()) {
            profesorRepository.delete(profesor.get());
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
