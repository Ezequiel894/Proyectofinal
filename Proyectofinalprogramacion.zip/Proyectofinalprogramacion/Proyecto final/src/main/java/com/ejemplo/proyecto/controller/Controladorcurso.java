package com.ejemplo.proyecto.controller;

import com.ejemplo.proyecto.model.Curso;
import com.ejemplo.proyecto.repository.Repositoriocurso;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/cursos")
public class Controladorcurso {

    @Autowired
    private Repositoriocurso cursoRepository;

    // Obtener todos los cursos
    @GetMapping
    public ResponseEntity<Iterable<Curso>> getAllCursos() {
        Iterable<Curso> cursos = cursoRepository.findAll();
        return ResponseEntity.ok(cursos);
    }

    // Obtener un curso por su ID
    @GetMapping("/{id}")
    public ResponseEntity<Curso> getCursoById(@PathVariable Long id) {
        Optional<Curso> curso = cursoRepository.findById(id);
        return curso.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Crear un nuevo curso
    @PostMapping
    public ResponseEntity<Curso> createCurso(@RequestBody Curso curso) {
        Curso savedCurso = cursoRepository.save(curso);
        return ResponseEntity.status(201).body(savedCurso);
    }

    // Actualizar un curso existente
    @PutMapping("/{id}")
    public ResponseEntity<Curso> updateCurso(@PathVariable Long id, @RequestBody Curso cursoDetails) {
        Optional<Curso> curso = cursoRepository.findById(id);
        if (curso.isPresent()) {
            Curso existingCurso = curso.get();
            existingCurso.setNombreCurso(cursoDetails.getNombreCurso());
            existingCurso.setDescripcionCurso(cursoDetails.getDescripcionCurso());
            existingCurso.setDuracionCurso(cursoDetails.getDuracionCurso());
            Curso updatedCurso = cursoRepository.save(existingCurso);
            return ResponseEntity.ok(updatedCurso);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Eliminar un curso
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCurso(@PathVariable Long id) {
        Optional<Curso> curso = cursoRepository.findById(id);
        if (curso.isPresent()) {
            cursoRepository.delete(curso.get());
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
