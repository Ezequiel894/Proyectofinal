package com.ejemplo.proyecto.repository;

import com.ejemplo.proyecto.model.Profesor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface repositorioprofresor extends JpaRepository<Profesor, Long> {
    // Aquí puedes agregar métodos de consulta personalizados si lo necesitas
}







