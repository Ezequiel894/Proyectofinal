package com.ejemplo.proyecto.controller;

import com.ejemplo.proyecto.model.Administrador;  // Cambié 'estudiante' por 'Administrador'
import com.ejemplo.proyecto.repository.repositorioadministrador;  // Cambié el repositorio a 'RepositorioAdministrador'
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/administradores")  // Modifiqué la ruta a '/api/administradores'
@CrossOrigin(origins = "*")  // Permite todas las solicitudes CORS de cualquier origen
public class ControladorAdministrador {  // Cambié el nombre del controlador a 'ControladorAdministrador'

    @Autowired
    private repositorioadministrador administradorRepository;  // Cambié 'estudianteRepository' por 'administradorRepository'

    // Obtener todos los administradores
    @GetMapping
    public ResponseEntity<Iterable<Administrador>> getAllAdministradores() {  // Cambié 'estudiantes' por 'administradores'
        Iterable<Administrador> administradores = administradorRepository.findAll();  // Cambié a 'administradorRepository'
        return ResponseEntity.ok(administradores);
    }

    // Obtener un administrador por su ID
    @GetMapping("/{id}")
    public ResponseEntity<Administrador> getAdministradorById(@PathVariable Long id) {  // Cambié 'estudiante' por 'administrador'
        Optional<Administrador> administrador = administradorRepository.findById(id);  // Cambié 'estudianteRepository' por 'administradorRepository'
        return administrador.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Crear un nuevo administrador
    @PostMapping
    public ResponseEntity<Administrador> createAdministrador(@RequestBody Administrador administrador) {  // Cambié 'estudiante' por 'administrador'
        Administrador savedAdministrador = administradorRepository.save(administrador);  // Cambié 'estudianteRepository' por 'administradorRepository'
        return ResponseEntity.status(201).body(savedAdministrador);
    }

    // Actualizar un administrador existente
    @PutMapping("/{id}")
    public ResponseEntity<Administrador> updateAdministrador(@PathVariable Long id, @RequestBody Administrador administradorDetails) {  // Cambié 'estudiante' por 'administrador'
        Optional<Administrador> administrador = administradorRepository.findById(id);  // Cambié 'estudianteRepository' por 'administradorRepository'
        if (administrador.isPresent()) {
            Administrador existingAdministrador = administrador.get();
            existingAdministrador.setNombreAdministrador(administradorDetails.getNombreAdministrador());  // Cambié 'nombreEstudiante' por 'nombreAdministrador'
            existingAdministrador.setCorreoAdministrador(administradorDetails.getCorreoAdministrador());  // Cambié 'correoEstudiante' por 'correoAdministrador'
            administradorRepository.save(existingAdministrador);  // Cambié 'estudianteRepository' por 'administradorRepository'
            return ResponseEntity.ok(existingAdministrador);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Eliminar un administrador
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAdministrador(@PathVariable Long id) {  // Cambié 'estudiante' por 'administrador'
        Optional<Administrador> administrador = administradorRepository.findById(id);  // Cambié 'estudianteRepository' por 'administradorRepository'
        if (administrador.isPresent()) {
            administradorRepository.delete(administrador.get());  // Cambié 'estudianteRepository' por 'administradorRepository'
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
