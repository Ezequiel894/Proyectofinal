package com.ejemplo.proyecto.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Column;

@Entity
public class Administrador {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    
    private long codigoAdministrador;

    @Column(name = "nombre_administrador")
    private String nombreAdministrador;

    @Column(name = "correo_administrador")
    private String correoAdministrador;

    // Constructor vacío (requerido por JPA)
    public Administrador() {}

    // Constructor para facilitar la creación de instancias
    public Administrador(String nombreAdministrador, String correoAdministrador) {
        this.nombreAdministrador = nombreAdministrador;
        this.correoAdministrador = correoAdministrador;
    }

    // Getters y Setters
    public long getCodigoAdministrador() {
        return codigoAdministrador;
    }

    public void setCodigoAdministrador(long codigoAdministrador) {
        this.codigoAdministrador = codigoAdministrador;
    }

    public String getNombreAdministrador() {
        return nombreAdministrador;
    }

    public void setNombreAdministrador(String nombreAdministrador) {
        this.nombreAdministrador = nombreAdministrador;
    }

    public String getCorreoAdministrador() {
        return correoAdministrador;
    }

    public void setCorreoAdministrador(String correoAdministrador) {
        this.correoAdministrador = correoAdministrador;
    }

    @Override
    public String toString() {
        return "Administrador{" +
                "codigoAdministrador=" + codigoAdministrador +
                ", nombreAdministrador='" + nombreAdministrador + '\'' +
                ", correoAdministrador='" + correoAdministrador + '\'' +
                '}';
    }
}
