package com.ejemplo.proyecto.controller;

import com.ejemplo.proyecto.model.estudiante;
import com.ejemplo.proyecto.repository.repositorioestudiante;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/estudiantes")
@CrossOrigin(origins = "*")  // Permite todas las solicitudes CORS de cualquier origen
public class controladorestudiante {

    @Autowired
    private repositorioestudiante estudianteRepository;

    // Obtener todos los estudiantes
    @GetMapping
    public ResponseEntity<Iterable<estudiante>> getAllEstudiantes() {
        Iterable<estudiante> estudiantes = estudianteRepository.findAll();
        return ResponseEntity.ok(estudiantes);
    }

    // Obtener un estudiante por su ID
    @GetMapping("/{id}")
    public ResponseEntity<estudiante> getEstudianteById(@PathVariable Long id) {
        Optional<estudiante> estudiante = estudianteRepository.findById(id);
        return estudiante.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Crear un nuevo estudiante
    @PostMapping
    public ResponseEntity<estudiante> createEstudiante(@RequestBody estudiante estudiante) {
        estudiante savedEstudiante = estudianteRepository.save(estudiante);
        return ResponseEntity.status(201).body(savedEstudiante);
    }

    // Actualizar un estudiante existente
    @PutMapping("/{id}")
    public ResponseEntity<estudiante> updateEstudiante(@PathVariable Long id, @RequestBody estudiante estudianteDetails) {
        Optional<estudiante> estudiante = estudianteRepository.findById(id);
        if (estudiante.isPresent()) {
            estudiante existingEstudiante = estudiante.get();
            existingEstudiante.setNombreEstudiante(estudianteDetails.getNombreEstudiante());
            existingEstudiante.setApellidoEstudiante(estudianteDetails.getApellidoEstudiante());
            existingEstudiante.setCorreoEstudiante(estudianteDetails.getCorreoEstudiante());
            estudiante updatedEstudiante = estudianteRepository.save(existingEstudiante);
            return ResponseEntity.ok(updatedEstudiante);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Eliminar un estudiante
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEstudiante(@PathVariable Long id) {
        Optional<estudiante> estudiante = estudianteRepository.findById(id);
        if (estudiante.isPresent()) {
            estudianteRepository.delete(estudiante.get());
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
