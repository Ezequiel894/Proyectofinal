package com.ejemplo.proyecto.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import java.util.Comparator;





@Entity
public class Calificaciones {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long codigoCalificacion;  // ID único para la calificación

    private double calificacion;  // La calificación del estudiante

    @ManyToOne
    private estudiante estudiante;  // El estudiante que recibió la calificación

    @ManyToOne
    private Curso curso;  // El curso en el que el estudiante recibió la calificación

    // Constructor vacío (requerido por JPA)
    public Calificaciones() {}

    // Constructor con parámetros para facilitar la creación
    public Calificaciones(double calificacion, estudiante estudiante, Curso curso) {
        this.calificacion = calificacion;
        this.estudiante = estudiante;
        this.curso = curso;
    }

    // Getters y Setters
    public long getCodigoCalificacion() {
        return codigoCalificacion;
    }

    public void setCodigoCalificacion(long codigoCalificacion) {
        this.codigoCalificacion = codigoCalificacion;
    }

    public double getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(double calificacion) {
        this.calificacion = calificacion;
    }

    public estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(estudiante estudiante) {
        this.estudiante = estudiante;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    @Override
    public String toString() {
        return "Calificacion{" +
                "codigoCalificacion=" + codigoCalificacion +
                ", calificacion=" + calificacion +
                ", estudiante=" + estudiante.getNombreEstudiante() + " " + estudiante.getApellidoEstudiante() +
                ", curso=" + curso.getNombreCurso() +
                '}';
    }
}
