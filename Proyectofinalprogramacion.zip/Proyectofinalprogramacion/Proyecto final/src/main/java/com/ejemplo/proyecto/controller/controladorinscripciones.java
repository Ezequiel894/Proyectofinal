package com.ejemplo.proyecto.controller;

import com.ejemplo.proyecto.model.inscripciones;
import com.ejemplo.proyecto.repository.repositorioinscripciones;
import com.ejemplo.proyecto.repository.repositorioestudiante;
import com.ejemplo.proyecto.repository.Repositoriocurso;
import com.ejemplo.proyecto.model.estudiante;
import com.ejemplo.proyecto.model.Curso;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;




@RestController
@RequestMapping("/api/inscripciones")
public class controladorinscripciones {

    @Autowired
    private repositorioinscripciones inscripcionRepository;

    @Autowired
    private repositorioestudiante estudianteRepository;

    @Autowired
    private Repositoriocurso cursoRepository;

    // Obtener todas las inscripciones
    @GetMapping
    public ResponseEntity<Iterable<inscripciones>> getAllInscripciones() {
        Iterable<inscripciones> inscripciones = inscripcionRepository.findAll();
        return ResponseEntity.ok(inscripciones);
    }

    // Obtener una inscripción por su ID
    @GetMapping("/{id}")
    public ResponseEntity<inscripciones> getInscripcionById(@PathVariable Long id) {
        Optional<inscripciones> inscripcion = inscripcionRepository.findById(id);
        return inscripcion.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Crear una nueva inscripción
    @PostMapping
    public ResponseEntity<inscripciones> createInscripcion(@RequestBody inscripciones inscripcion) {
        // Verificar si el estudiante y el curso existen en la base de datos
        Optional<estudiante> estudiante = estudianteRepository.findById(inscripcion.getEstudiante().getCodigoEstudiante());
        Optional<Curso> curso = cursoRepository.findById(inscripcion.getCurso().getCodigoCurso());

        if (estudiante.isPresent() && curso.isPresent()) {
            inscripciones savedInscripcion = inscripcionRepository.save(inscripcion);
            return ResponseEntity.status(201).body(savedInscripcion);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    // Eliminar una inscripción
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInscripcion(@PathVariable Long id) {
        Optional<inscripciones> inscripcion = inscripcionRepository.findById(id);
        if (inscripcion.isPresent()) {
            inscripcionRepository.delete(inscripcion.get());
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
