package com.ejemplo.proyecto.repository;

import com.ejemplo.proyecto.model.Administrador;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface repositorioadministrador extends JpaRepository<Administrador, Long> {
    // Puedes agregar métodos de consulta personalizados si lo necesitas
}
