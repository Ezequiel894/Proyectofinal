package com.ejemplo.proyecto.repository;

import com.ejemplo.proyecto.model.Curso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Repositoriocurso extends JpaRepository<Curso, Long> {
    // Aquí puedes agregar métodos de consulta personalizados si lo necesitas
}
