package com.ejemplo.proyecto.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Column;

@Entity
public class estudiante {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long codigoEstudiante;

    @Column(name = "nombre_estudiante")
    private String nombreEstudiante;

    @Column(name = "apellido_estudiante")
    private String apellidoEstudiante;

    @Column(name = "correo_estudiante")
    private String correoEstudiante;

    // Constructor vacío (requerido por JPA)
    public estudiante() {}

    // Constructor para facilitar la creación de instancias
    public estudiante(String nombreEstudiante, String apellidoEstudiante, String correoEstudiante) {
        this.nombreEstudiante = nombreEstudiante;
        this.apellidoEstudiante = apellidoEstudiante;
        this.correoEstudiante = correoEstudiante;
    }

    // Getters y Setters
    public long getCodigoEstudiante() {
        return codigoEstudiante;
    }

    public void setCodigoEstudiante(long codigoEstudiante) {
        this.codigoEstudiante = codigoEstudiante;
    }

    public String getNombreEstudiante() {
        return nombreEstudiante;
    }

    public void setNombreEstudiante(String nombreEstudiante) {
        this.nombreEstudiante = nombreEstudiante;
    }

    public String getApellidoEstudiante() {
        return apellidoEstudiante;
    }

    public void setApellidoEstudiante(String apellidoEstudiante) {
        this.apellidoEstudiante = apellidoEstudiante;
    }

    public String getCorreoEstudiante() {
        return correoEstudiante;
    }

    public void setCorreoEstudiante(String correoEstudiante) {
        this.correoEstudiante = correoEstudiante;
    }

    @Override
    public String toString() {
        return "Estudiante{" +
                "codigoEstudiante=" + codigoEstudiante +
                ", nombreEstudiante='" + nombreEstudiante + '\'' +
                ", apellidoEstudiante='" + apellidoEstudiante + '\'' +
                ", correoEstudiante='" + correoEstudiante + '\'' +
                '}';
    }
}
