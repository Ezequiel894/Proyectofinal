document.addEventListener('DOMContentLoaded', function () {
  const registerForm = document.getElementById('registerForm');
  const studentList = document.getElementById('studentList');
  const errorMessage = document.getElementById('error-message');

  // Cargar la lista de estudiantes al cargar la página
  loadStudents();

  // Evento de envío del formulario
  registerForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const nombreEstudiante = document.getElementById('nombreEstudiante').value;
      const apellidoEstudiante = document.getElementById('apellidoEstudiante').value;
      const correoEstudiante = document.getElementById('correoEstudiante').value;

      // Verificar que los campos no estén vacíos
      if (!nombreEstudiante || !apellidoEstudiante || !correoEstudiante) {
          alert("Por favor, completa todos los campos.");
          return;
      }

      // Realizar la solicitud para registrar al estudiante
      fetch('http://localhost:8080/api/estudiantes', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json'
          },
          body: JSON.stringify({
              nombreEstudiante: nombreEstudiante,
              apellidoEstudiante: apellidoEstudiante,
              correoEstudiante: correoEstudiante
          })
      })
      .then(response => response.json())
      .then(data => {
          if (data && data.codigoEstudiante) {
              // Si el registro fue exitoso, limpiar el formulario y recargar la lista
              alert('Estudiante registrado exitosamente');
              registerForm.reset();
              loadStudents();
          } else {
              errorMessage.style.display = 'block';
          }
      })
      .catch(error => {
          console.error('Error al registrar el estudiante:', error);
          alert('Hubo un error al registrar el estudiante.');
      });
  });

  // Función para cargar la lista de estudiantes
  function loadStudents() {
      fetch('http://localhost:8080/api/estudiantes')
          .then(response => response.json())
          .then(data => {
              // Limpiar la lista de estudiantes antes de agregar los nuevos
              studentList.innerHTML = '';

              if (Array.isArray(data) && data.length > 0) {
                  data.forEach(estudiante => {
                      const li = document.createElement('li');
                      li.textContent = `${estudiante.nombreEstudiante} ${estudiante.apellidoEstudiante} - ${estudiante.correoEstudiante}`;
                      studentList.appendChild(li);
                  });
              } else {
                  studentList.innerHTML = '<li>No hay estudiantes registrados.</li>';
              }
          })
          .catch(error => {
              console.error('Error al cargar la lista de estudiantes:', error);
              alert('Hubo un error al cargar la lista de estudiantes.');
          });
  }
});
