-- --------------------------------------------------------
-- Host:                         localhost
-- Versión del servidor:         11.5.2-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando datos para la tabla finalproyecto.administrador: ~0 rows (aproximadamente)

-- Volcando datos para la tabla finalproyecto.calificaciones: ~4 rows (aproximadamente)
INSERT INTO `calificaciones` (`codigo_calificacion`, `calificacion`, `curso_codigo_curso`, `estudiante_codigo_estudiante`) VALUES
	(1, 8.5, 1, 1),
	(2, 9, 2, 2),
	(3, 7.5, 3, 3),
	(4, 10, 4, 4);

-- Volcando datos para la tabla finalproyecto.curso: ~4 rows (aproximadamente)
INSERT INTO `curso` (`codigo_curso`, `nombre_curso`, `descripcion_curso`, `duracion_curso`) VALUES
	(1, 'Matemáticas 101', 'Curso básico de matemáticas, enfoque en álgebra y cálculo', 40),
	(2, 'Historia Universal', 'Estudio de la historia desde la prehistoria hasta la edad media', 45),
	(3, 'Programación en Java', 'Curso introductorio sobre desarrollo en Java y programación orientada a objetos', 30),
	(4, 'Física I', 'Fundamentos de física, incluyendo movimiento, energía y ley de Newton', 50);

-- Volcando datos para la tabla finalproyecto.estudiante: ~7 rows (aproximadamente)
INSERT INTO `estudiante` (`codigo_estudiante`, `nombre_estudiante`, `apellido_estudiante`, `correo_estudiante`) VALUES
	(1, 'Juan', 'Pérez', 'juan.perez@email.com'),
	(2, 'Ana', 'González', 'ana.gonzalez@email.com'),
	(3, 'Carlos', 'Sánchez', 'carlos.sanchez@email.com'),
	(4, 'Laura', 'Martínez', 'laura.martinez@email.com'),
	(5, 'Eliu', 'De la cruz', 'prueba@gmail.com'),
	(6, 'dylan', 'rustrian', 'prueba2@gmail.com'),
	(7, 'prueba', 'prueba2', 'prueba3@gmail.com');

-- Volcando datos para la tabla finalproyecto.inscripciones: ~4 rows (aproximadamente)
INSERT INTO `inscripciones` (`codigo_inscripcion`, `fecha_inscripcion`, `curso_codigo_curso`, `estudiante_codigo_estudiante`) VALUES
	(1, '2024-09-01', 1, 1),
	(2, '2024-09-02', 2, 2),
	(3, '2024-09-03', 3, 3),
	(4, '2024-09-04', 4, 4);

-- Volcando datos para la tabla finalproyecto.profesor: ~3 rows (aproximadamente)
INSERT INTO `profesor` (`codigo_profesor`, `nombre_profesor`, `apellido_profesor`, `correo_profesor`) VALUES
	(1, 'Pedro', 'López', 'pedro.lopez@email.com'),
	(2, 'Marta', 'Díaz', 'marta.diaz@email.com'),
	(3, 'Javier', 'Fernández', 'javier.fernandez@email.com');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
